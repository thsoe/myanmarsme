-- phpMyAdmin SQL Dump
-- version 2.11.11.3
-- http://www.phpmyadmin.net
--
-- Host: 184.168.228.8
-- Generation Time: Apr 20, 2013 at 08:40 PM
-- Server version: 5.0.96
-- PHP Version: 5.1.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `msmeadmin`
--

-- --------------------------------------------------------

--
-- Table structure for table `company_info`
--

CREATE TABLE `company_info` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `name` varchar(200) NOT NULL,
  `logo` varchar(200) NOT NULL default '/images/img_no.png',
  `description` varchar(500) default NULL,
  `longDesc` longtext,
  `image1` varchar(200) NOT NULL default '/images/img_no.png',
  `image2` varchar(200) NOT NULL default '/images/img_no.png',
  `image3` varchar(200) NOT NULL default '/images/img_no.png',
  `image4` varchar(200) NOT NULL default '/images/img_no.png',
  `image5` varchar(200) NOT NULL default '/images/img_no.png',
  `image6` varchar(200) NOT NULL default '/images/img_no.png',
  `businessAddress` varchar(500) NOT NULL,
  `worksiteAddress` varchar(500) NOT NULL,
  `contactNo1` varchar(100) default NULL,
  `contactNo2` varchar(100) default NULL,
  `ad` varchar(200) default NULL,
  `rank` bigint(20) unsigned default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `company_info`
--

INSERT INTO `company_info` VALUES(1, 'Accord Aluminium Art', '/images/com_accord.png', 'Aluminium Frames &amp; Furniture Production, Decoration with aluminium product.', '<strong>Accord Aluminium Art Pte Ltd</strong> first began supplying aluminium extrusions to customers in Myanmar in 1976. Today, the company supplies and distributes an extensive range of aluminium products to customers in many industrial sectors and represents some of the world''s reputable aluminium manufacturers.<br/><br/>With more than 25 years of experience in dealing with aluminium, the company believes the key to its success is in being customer-focused. It has earned and enjoyed a reputation for providing professional quality service and products. <strong>Accord Aluminium Art Pte Ltd</strong> strives to be an Aluminium Specialist, providing solutions to customers'' needs. The company has also constantly invested in processing equipment and facilities, aiming to be a one-stop Supply & Service Center in Myanmar. It is committed to deliver better services and quality products to customers in Myanmar and the region. Its staff will stand behind the company''s image and reputation as a leader in the aluminium business in Myanmar to implement the ISO9001:2000 Quality Management System and improve their skills to achieve Total Customer Satisfaction.<br/><br/><strong>Accord Aluminium Art Pte Ltd</strong> is continuously striving its best to achieve a higher standard in quality management and a better recognition of quality performance from its customers. The company''s Quality Management Systems will be reviewed for continuing suitability to meet changing needs of its customers.', '/images/a1_p1.png', '/images/a1_p2.png', '/images/a1_p3.png', '/images/a1_s1.png', '/images/a1_s2.png', '/images/a1_s3.png', '45-M, Tay Nu Yin Avenue,<br />7½ Mile, Prome Rd., Mayangone Township<br />Yangon', '45-M, Tay Nu Yin Avenue,<br />7½ Mile, Prome Rd., Mayangone Township<br />Yangon', '+95 095110184', '+95 541122', '/images/a1_p1.png', 1);
INSERT INTO `company_info` VALUES(2, 'Arkar Tun', '/images/img_no.png', '(Rm 7), 81, Nilar 8th St., SawbwargyiGoneHighwayBusesCentre, Saw Bwar Gyi Gone Ward', NULL, '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '(Rm 7), 81, Nilar 8th St., SawbwargyiGoneHighwayBusesCentre, Saw Bwar Gyi Gone Ward', '', NULL, NULL, NULL, 2);
INSERT INTO `company_info` VALUES(3, 'Arr Thit', '/images/com_arrThit.png', 'Agricultural Machinery &amp; Tools Production', NULL, '/images/com_arrThit.png', '/images/ads3.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '', '', NULL, NULL, '/images/ads3.png', 3);
INSERT INTO `company_info` VALUES(4, 'AutoSphere', '/images/img_no.png', 'Air-Conditioning &amp; Engineering,Autosphere Airconditioning is in the business of creating cool atmosphere for all our client for over 10 years. We specialised in installation, maintenance and repairs of all types of airconditioning and mechanical ventilation systems.', NULL, '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '', '', NULL, NULL, NULL, NULL);
INSERT INTO `company_info` VALUES(5, 'Cans Mfg Co.Ltd', '/images/img_no.png', 'Can Making for Food Stuff and Other Packaging.', NULL, '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '', '', '', '', NULL, NULL);
INSERT INTO `company_info` VALUES(9, 'Gate Master', '/images/img_no.png', 'Gate Master an established company, with more than 10 years of rich experience in the auto gate industry.', NULL, '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '', '', NULL, NULL, NULL, NULL);
INSERT INTO `company_info` VALUES(6, 'City Designer', '/images/img_no.png', 'City Designer  is an interior design firm providing interior design and furnishing solutions. Building services available as well.', NULL, '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '', '', NULL, NULL, NULL, NULL);
INSERT INTO `company_info` VALUES(7, 'Golden Horse Co.,Ltd', '/images/com_gHorse.png', 'Export &amp; Import, Agricultural Merchants, Cooking Oil', NULL, '/images/com_gHorse.png', 'images/ads2.png', '/images/gh2.PNG', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', 'Bldg 67/A, Bogyoke Aung San Rd., Between Lan Thit St.and War Dan St., Bahosi Housing, Ward (10), LMDW', 'D/9/A,Aung Thapyae Street,MayangoneTsp, Yangon', '680012', '682350, 227802~3, 222951', 'images/ads2.png', NULL);
INSERT INTO `company_info` VALUES(8, 'Golden Lions Enterprise Ltd', '/images/com_gl.png', 'Export &amp; Import Companies, Foodstuffs, Beans &amp; Pulses', NULL, '/images/com_gl.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '', '', NULL, NULL, NULL, NULL);
INSERT INTO `company_info` VALUES(10, 'Linpo Co., Ltd', '/images/com_linpo.png', 'Stainless Steel Wares,Tiles (Wall, Floor), Ceiling Materials, Aluminium Frames  Decoration Services', NULL, '/images/com_linpo.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '', '', NULL, NULL, NULL, NULL);
INSERT INTO `company_info` VALUES(11, 'Myanmar Destination Management Company', '/images/M-DMC.png', 'Myanmar Destination Management Company is a fully licensed incoming travel company under the Ministry of Hotel and Tourism, Myanmar. The registered office of Myanmar DMC is located in Yangon, the gateway and business hub of Myanmar.', '<strong>Myanmar Destination Management Company</strong> is a fully licensed incoming travel company under the Ministry of Hotel and Tourism, Myanmar. The registered office of Myanmar DMC is located in Yangon, the gateway and business hub of Myanmar. The management of Myanmar Destination Management Company is comprised of proficient executives who possess over 70 years of collective experience in Tourism Industry. We provide flawless, comprehensive solutions to International Tour Operators, Travel Agents, Event Planners, Corporations and Associations who require personalized service and are seeking the most cost-effective, innovative and highest quality programs.</p><br /><p><br /><br /><h3>Mission</h3><p>Our Mission is to exceed the expectations of our valued clients at all times by providing utmost possible services with personal touch that always outshine.</p><br /><h3>Vision</h3><p>Our vision is to be the most reliable and successful Destination Management Company in Myanmar travel industry by consistently and constantly striving to develop new business relationships and potential market niches.</p><br /><p style=''border-bottom:1px dotted #ccc;''></p><br /><h3 style=''color:#8A4E10;''>Our Core Values</h3><br /><ul style=''font-style:italic;''><li>&raquo; We are motivated by love for country.</li><li>&raquo; We respect our cultural and historical heritage.</li><li>&raquo; We conserve our environment.</li><li>&raquo; We are highly customer oriented company.</li><li>&raquo; We have a clear understanding of the needs of clients.</li><li>&raquo; We are committed to maintain the highest standard of professional service that always surpasses.</li><li>&raquo; We are committed to delight our clients with new and innovative ideas.</li><li>&raquo; We are committed to provide our clients with optimum values for money.</li><li>&raquo; We take great pride in assisting our clients.</li></ul><br /><p style=''border-bottom:1px dotted #ccc;''></p><br /><h3 style=''color:#8A4E10;''>Why Myanmar DMC?</h3><br /><h3>The Team:</h3><p>We are a team of knowledgeable, dedicated, passionate and creative professionals with tremendous exposure in Tourism Industry. <strong>We are Myanmar, we live in Myanmar and we know Myanmar better than others.</strong></p><br /><h3>Values - What you are looking for:</h3><p>Our responsibility is to make our clients'' travels or events unforgettable, more memorable and a truly magical experience. In doing so, unlike other mass-producing travel companies, we will meet and exceed clients'' expectations of:</p><ul style=''font-style:italic;''><li>&raquo; Uncompromised Highest Industry Standards </li><li>&raquo; Unique Programs with Personalize Service</li><li>&raquo; Optimum value for money </li><li>&raquo; Cost Effectiveness</li><li>&raquo; Flexibility</li><li>&raquo; Total Client Satisfaction</li><li>&raquo; Multitude of Specialties</li><li>&raquo; Special Attention on Safety</li><li>&raquo; Financial Stability </li></ul><br /><h3>Relationships: </h3><p>When you choose us, you choose the best DMC that has strong relationships and purchasing power with local suppliers to provide the highest quality of service in the most cost-effective manner. </p><br /><h3>24 X 7 Personalized Customer Service </h3><p>We understand that every single client has unique requirements and individual preferences. We, therefore, are committed to go the extra mile to accomplish them. Our dedicated team is extremely flexible, always accessible and can be reached 24 X 7 to fulfill your needs.', '/images/M-DMC.png', '/images/Hotel-Tourism-logo.png', '/images/umfcci_logo.png', '/images/M-DMC-mth-promo.png', '/images/M-DMC-npl1.png', '/images/Cruise-amr2.png', 'F-38, Shwe Sabai 3rd Street,<br />FMI CityHlaing Thar Yar Township,<br />Yangon, Myanmar<br /><a href=''http://www.myanmar-dmc.net'' target=''_blank'' style=''color:#8A4E10;''>www.myanmar-dmc.net</a>', 'F-38, Shwe Sabai 3rd Street,<br />FMI CityHlaing Thar Yar Township,<br />Yangon, Myanmar<br /><a href=''http://www.myanmar-dmc.net'' target=''_blank'' style=''color:#8A4E10;''>www.myanmar-dmc.net</a>', '<strong>Tel </strong>: +95-1-687127, +95-9-73016397,<br />+95-9-2305135, +95-9-49278443<br />', '<strong>Fax</strong> : +95-1-687127', NULL, NULL);
INSERT INTO `company_info` VALUES(12, 'Sandhi Management School &amp; Local Consultancy', '/images/Sandhi-logo.png', 'Sandhi Management School  was founded in 2010 to provide quality development and human resource trainings for people who are working CBOs/NGOs as well as for those who aspire to become leaders in their community development work', '<strong>Sandhi Management School</strong>  was founded in 2010 to provide quality development and human resource trainings for people who are working CBOs/NGOs as well as for those who aspire to become leaders in their community development work. The school''s mission is to nurture good and competent leadership in development organizations which will contribute to longterm sustainable development. Although it is a for-profit organization, it will offer generous scholarships to those who are actively involved in the humanitarian and development projects of community-based organizations and local NGOs.</p><br /><br /><br /><br /><h3 style=''color:#006500;''><strong>COURSES OFFERED AT SANDHI MANAGEMENT SCHOOL</strong></h3><br />Development training courses are divided into 3 levels - basic, intermediate and advanced. Each level consists of 4 courses and they are designed to suit the needs of the trainees depending on their knowledge and skills of development work. <br /><br /><h3>Basic Level </h3>&raquo; What is development?<br />&raquo; Leadership Skills<br />&raquo; Community Mobilization<br />&raquo; Team building & Conflict resolution<br /><br /><strong>Eligibility:</strong> Training courses in this level are suitable for those who have never attended development trainings and/or have very little knowledge about the basic concepts of development and the roles development workers can play to lay basic foundations for development in their respective communities.<br /><br /><h3>Intermediate Level</h3>&raquo; Proposal Writing<br />&raquo; Effective Communication Skills<br />&raquo; Project Cycle Management<br />&raquo; Monitoring & Evaluation<br /><br /><strong>Eligibility:</strong> Training courses in this level are suitable for development workers who have to participate in one or all the stages of the project cycle; from planning, designing, implementation to evaluation. <br /><br /><h3>Advanced Level</h3>&raquo; Organizational Management<br />&raquo; Strategic Planning<br />&raquo; Social Research Skills<br />&raquo; Tools for Development Workers<br /><br /><strong>Eligibility:</strong> Training courses in this level are suitable for development workers who are taking managerial positions in their organizations effectively but also think strategically for organizational development and long-term sustainability. <br /><br />In addition to above-mentioned development training courses, Sandhi Management School organizes workshops on topics which are related to development such as good governance, civil society, public policy advocacy, accountability etc under the heading of development workshop series. <br /><br /><h3 style=''color:#006500;''>RESOURCE PERSONS</h3>Trainings will be conducted by development practitioners/trainers who have been actively involved in development programs/projects of international aid agencies and local NGOs. All the trainings are conducted using participatory methods. Training materials are available both in Myanmar and English and all the trainings are facilitated in Myanmar. In addition to above mentioned development training program, Sandhi Management School also offers English language skills training for CBOs/NGOs workers and other operations related trainings for operation staff.', '/images/Sandhi-logo.png', '/images/Sandhi-1.png', '/images/Sandhi-2.png', '/images/Sandhi-3.png', '/images/Sandhi-4.png', '/images/Sandhi-5.png', '256/266 (2B) Seikkantha Road, <br />Kyauktada Township, Yangon, Myanmar', '256/266 (2B) Seikkantha Road, <br />Kyauktada Township, Yangon, Myanmar', '<strong>Phone</strong>:  95 973074219<br />', '<strong>E-mail</strong>: <a href=''mailto:sandhi.consultancy@gmail.com'' style=''color:#006500;''>sandhi', NULL, NULL);
INSERT INTO `company_info` VALUES(13, 'Shwe La Min', '/images/com_shweLaMin.png', 'Boilers &amp; Accessories Dealer/Repair Service', NULL, '/images/com_shweLaMin.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '', '', NULL, NULL, NULL, NULL);
INSERT INTO `company_info` VALUES(14, 'Three Star', '/images/img_no.png', 'Since 1997, Three Star Construction has been working closely and adhering to Home Services standards. We show professional responsibility for our work and for the work of our colleagues who are defined as working under our employment or supervision.', NULL, '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '', '', NULL, NULL, NULL, NULL);
INSERT INTO `company_info` VALUES(15, 'United Can Factory Co.,Ltd.', '/images/img_no.png', 'Can Making, Packing &amp; Wrapping Equipments', NULL, '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '', '', NULL, NULL, NULL, NULL);
INSERT INTO `company_info` VALUES(16, 'WN Carton Box', '/images/com_wn.png', '1023/1025, Shwe Taung Kyar-6 St., Ward 63, Industrial Zone 2, Yangon,South Dagon Township', NULL, '/images/com_wn.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '1023/1025, Shwe Taung Kyar-6 St., Ward 63, Industrial Zone 2, Yangon,South Dagon Township', '1023/1025, Shwe Taung Kyar-6 St., Ward 63, Industrial Zone 2, Yangon,South Dagon Township', NULL, NULL, NULL, NULL);
INSERT INTO `company_info` VALUES(17, 'WoodKing', '/images/img_no.png', 'We provides a wide range of services and  supply indoor &amp; outdoor timberworks, including landscape designs for both residential and commercial projects.', NULL, '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '', '', NULL, NULL, NULL, NULL);
INSERT INTO `company_info` VALUES(18, 'Zwe [U Soe Than + Daw Lay Kyi Family]', '/images/com_zwe.png', 'Agricultural Machinery &amp; Tools, Machinery &amp; Spareparts Dealers', NULL, '/images/com_zwe.png', '/images/ads1.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', '/images/img_no.png', 'B/55,Yadana Theingi Street,South DagonTsp, Yangon', 'B/55,Yadana Theingi Street,South DagonTsp, Yangon', '590910', '095008392, 095035000', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `industrialZones`
--

CREATE TABLE `industrialZones` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `name` varchar(200) NOT NULL,
  `lat` varchar(200) NOT NULL,
  `lng` varchar(200) NOT NULL,
  `address` varchar(200) default NULL,
  `contactNo` varchar(200) default NULL,
  `contactNo2` varchar(200) default NULL,
  `contactNo3` varchar(200) default NULL,
  `area` varchar(200) default NULL,
  `stateDvision` varchar(200) default NULL,
  `midcZone` varchar(200) default NULL,
  `establishmentYear` varchar(200) default NULL,
  `industryCount` varchar(200) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `industrialZones`
--

INSERT INTO `industrialZones` VALUES(1, 'South Dagon Industrial Zone 1', '16.829642', '96.219164', 'No 509, Industrial Zone 1 Road, South Dagon Township, Yangon, Myanmar [Burma]', '590232', '098602390', '73014966', '475.354 acre', 'Yangon Division', 'Yangon East District', '1992', '128');
INSERT INTO `industrialZones` VALUES(4, 'North Okkalapa', '16.910607', '96.157923', 'Khay Mar Thi Street,North OkkalapaTsp, Yangon', '690281', '691818', '691819', '109.789 acres', 'Yangon Division', 'Yangon East District', '1999', '115');
INSERT INTO `industrialZones` VALUES(3, 'South Dagon Industrial Zone 3', '16.842559', '96.225944', 'Set Hmu Zone 1st Street, South DagonTsp, Yangon', '590268', '590270', '098602395,098602394', '35.280 acre', 'Yangon Division', 'Yangon East District', '1995', '371');
INSERT INTO `industrialZones` VALUES(2, 'South Dagon Industrial Zone 2', '16.840649', '96.230503', 'Innya Road, South Dagon Township, Yangon, Myanmar [Burma]', '590542', '594300', '-', '203.784 acre', 'Yangon Division', 'Yangon East District', '1992', '525');
INSERT INTO `industrialZones` VALUES(5, 'South Okkalapa', '16.836788', '96.174574', '3,Set Hmu 3rd Street,South OkkalapaTsp, Yangon', '560752', '-', '-', '25.000 acres', 'Yangon Division', 'Yangon East District', '1999', '98');
INSERT INTO `industrialZones` VALUES(6, 'Shwe Paukkan', '16.929966', '96.183543', '54,Bagan Road,North OkkalapaTsp, Yangon', '695256', '-', '-', '94.640 acres', 'Yangon Division', 'Yangon East District', '1992', '72');
INSERT INTO `industrialZones` VALUES(7, 'Thakayta', '16.806513', '96.200409', '296,Mya Malar Street,ThaketaTsp, Yangon', '547397', '098602412', '-', '200.000 acres', 'Yangon Division', 'Yangon East District', '1999', '82');
INSERT INTO `industrialZones` VALUES(8, 'Dagon Seikkan', '16.834652', '96.283708', '97,Phan Chat Wun U Shwe Owe Street,Dagon SeikkanTsp, Yangon', '592051', '098601360', '592189', '1208.695 acre', 'Yangon Division', 'Yangon East District', '2000', '24');
INSERT INTO `industrialZones` VALUES(9, 'Yangon West District Industrial Zone', '16.780547', '96.132431', '-', '-', '-', '-', '-', 'Yangon Division', 'Yangon West District', '-', '1,003');
INSERT INTO `industrialZones` VALUES(10, 'Hlaing Thayar', '16.917567', '96.06617', '1/A,Kanaung Min Thar Gyi Street,Hlaing TharyarTsp, Yangon', '681167', '684768', '685501, 685502, 685503', '986.540 acres', 'Yangon Division', 'Yangon North District', '1995', '219');
INSERT INTO `industrialZones` VALUES(11, 'Shwe Pyithar', '16.946429', '96.094408', 'Kanaung Min Gyi Street,Shwe Pyi TharTsp, Yangon', '610712', '612563', '612562', '306.976 acres', 'Yangon Division', 'Yangon North District', '1990', '101');
INSERT INTO `industrialZones` VALUES(12, 'Mandalay Industrial Zone-1', '21.920991', '96.107873', NULL, NULL, NULL, NULL, '809.510 acres', 'Mandalay Division', 'Mandalay', '1990', '661');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `url` varchar(200) NOT NULL,
  `title` varchar(200) NOT NULL,
  `snippet` varchar(200) default NULL,
  PRIMARY KEY  (`url`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `news`
--

INSERT INTO `news` VALUES('http://www.facebook.com/home.php?sk=group_133296600076131&amp;view=doc&amp;id=145349708870820', 'Product Pricing and Service Pricing', 'You guys might already have read this, and already known it, but at times, as you are thinking...');
INSERT INTO `news` VALUES('http://www.facebook.com/thefacebookeffect', 'The Facebook Effect, by David Kirkpatrick', 'David Kirkpatrick was for many years the senior editor for Internet &amp; Tech at...');
INSERT INTO `news` VALUES('http://www.learnoutloud.com/Free-Audio-Video/Technology/Internet/Free-The-Future-of-a-Radical-Price/31326', 'Free: The Future of a Radical Price by Chris Anderson', 'The New York Times best-selling author heralds the future of business in Free...');
INSERT INTO `news` VALUES('http://www.facebook.com/l.php?u=http%3A%2F%2Fwww.bernama.com%2Fbernama%2Fv5%2Fnewsbusiness.php%3Fid%3D574340&amp;h=e8052', 'www.bernama.com', 'BERNAMA - Matrade Urges Local Companies To Participate In CAEXPO 2011');
INSERT INTO `news` VALUES('http://www.facebook.com/l.php?u=http%3A%2F%2Fwww.google.com%2Furl%3Fsa%3DX%26q%3Dhttp%253A%252F%252Fwww.monstersandcritics.com%252Fnews%252Fasiapacific%252Fnews%252Farticle_1628624.php%252FMyanmar-s-n', 'www.monstersandcritics.com', 'Myanmar''s new government to start work on April 1 - Monsters and Critics');

-- --------------------------------------------------------

--
-- Table structure for table `smeuser`
--

CREATE TABLE `smeuser` (
  `fullName` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phoneNo` varchar(50) default NULL,
  PRIMARY KEY  (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `smeuser`
--

INSERT INTO `smeuser` VALUES('Nanda Aung', 'nanda.ag@gmail.com', '1234');
INSERT INTO `smeuser` VALUES('Aung Ko Ko Thet', 'aungkokothet@gmail.com', ' 6581831053');
INSERT INTO `smeuser` VALUES('admin', ' admin@yourmyanmarsme.com', NULL);
INSERT INTO `smeuser` VALUES('111', '111@111.11', NULL);
INSERT INTO `smeuser` VALUES('yimon', 'yimon.han@gmail.com', NULL);
INSERT INTO `smeuser` VALUES('Tin Htut Soe', 'tinhtutsoe@gmail.com', NULL);
INSERT INTO `smeuser` VALUES('test', 'test@test.com', '1234');
INSERT INTO `smeuser` VALUES('test2', 'test2@test.com', '12345');
INSERT INTO `smeuser` VALUES('test3', 'test3@test.com', '1234');
INSERT INTO `smeuser` VALUES('test4', 'test4@test.com', '1234');
INSERT INTO `smeuser` VALUES('test5', 'test5@test.com', '12345');
INSERT INTO `smeuser` VALUES('test6', 'test6@test.com', '1234');
INSERT INTO `smeuser` VALUES('Shein Myint Aung', 'nasper22@gmail.com', ' 9595203049');
INSERT INTO `smeuser` VALUES('Thet Naing Soe', 'soe.enterprise@gmail.com', '6591511377');
INSERT INTO `smeuser` VALUES('thanhtetaung', 'thanhtetaung87@gmail.com', '83837241');
INSERT INTO `smeuser` VALUES('garfield', 'garfield.mm@gmail.com', '');

-- --------------------------------------------------------

--
-- Table structure for table `smeuser2company`
--

CREATE TABLE `smeuser2company` (
  `email` varchar(100) NOT NULL,
  `companyId` bigint(20) NOT NULL,
  PRIMARY KEY  (`email`,`companyId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `smeuser2company`
--

INSERT INTO `smeuser2company` VALUES('nanda.ag@gmail.com', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `email` varchar(100) NOT NULL,
  `password` varchar(15) NOT NULL,
  PRIMARY KEY  (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` VALUES(' admin@yourmyanmarsme.com', '123');
INSERT INTO `user` VALUES('111@111.11', '111111');
INSERT INTO `user` VALUES('aungkokothet@gmail.com', 'nnnyantun');
INSERT INTO `user` VALUES('bbb12@gdgedf.vv', 'teetrette');
INSERT INTO `user` VALUES('garfield.mm@gmail.com', '1q2w3e4r%T');
INSERT INTO `user` VALUES('nanda.ag@gmail.com', '12345');
INSERT INTO `user` VALUES('nasper22@gmail.com', 'superkarawate');
INSERT INTO `user` VALUES('soe.enterprise@gmail.com', '123!@#');
INSERT INTO `user` VALUES('test2@test.com', 'password');
INSERT INTO `user` VALUES('test3@test.com', 'password');
INSERT INTO `user` VALUES('test4@test.com', 'password');
INSERT INTO `user` VALUES('test5@test.com', 'password');
INSERT INTO `user` VALUES('test6@test.com', 'password');
INSERT INTO `user` VALUES('test@test.com', 'password');
INSERT INTO `user` VALUES('thanhtetaung87@gmail.com', 'rooney');
INSERT INTO `user` VALUES('tinhtutsoe@gmail.com', '12qwaszx');
INSERT INTO `user` VALUES('yenaingaung@gmail.com', 'password');
INSERT INTO `user` VALUES('yimon.han@gmail.com', '123456');
